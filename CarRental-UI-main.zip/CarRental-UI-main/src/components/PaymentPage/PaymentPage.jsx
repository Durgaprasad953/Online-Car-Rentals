import React from "react";

const PaymentPage = () => {
    return (
        <div>
            <h1>HELLO payment</h1>
        </div>
    )
}

export default PaymentPage;