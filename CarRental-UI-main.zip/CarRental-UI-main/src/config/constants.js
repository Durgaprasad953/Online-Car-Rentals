
const constants = {
API_BASE_URL: 'https://carrental-api-ea7p.onrender.com',
//API_BASE_URL: 'http://localhost:3000',
   ADMIN_AUTHTOKEN : localStorage.getItem("adminAuthToken")
};

export default constants;